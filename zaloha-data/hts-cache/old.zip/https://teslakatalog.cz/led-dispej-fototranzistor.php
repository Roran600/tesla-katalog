<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>LED, displeje, fototranzistory</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<meta name="description" content="Katalog sou��stek - LED, displeje, fototranzistory - n�hrada str�nek io.freehosting.cz a io1.freehosting.cz a jejich dopln�n�">
<meta name="keywords" content="katalog, list, Tesla, LED, displej, fototranzistor">
<link href="stylcss.css" type="text/css" rel="stylesheet"></head><body>
<center>
<table border="0" cellpadding="4" cellspacing="2" width="800">
  <tbody><tr valign="top">

      <td class="leftMain" align="left" width="180"><table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>
        <td align="left" height="200" valign="top"><table border="0" cellpadding="3" cellspacing="1" width="100%">
          
          <tbody><tr>
            <td class="forMenu2" align="center" height="71" valign="middle"><br><br><a href="http://teslakatalog.cz"><img src="ikony/tesla_logo.gif" alt=" " border="0" height="116" width="112"></a><br><br><br></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="http://teslakatalog.cz">O webu</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="io.php">Integrovan� obvody</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tranzistor.php">Tranzistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tyristor-triak-diak.php">Tyristory, triaky</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="dioda-varikap.php">Diody, varikapy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="led-dispej-fototranzistor.php">Displeje, LED</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="kondenzator.php">Kondenz�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="rezistor.php">Rezistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tlumivka.php">Tlumivky, filtry</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="xtal.php">Krystaly, oscil�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="termistor.php">Termistory Pramet</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle">&nbsp;</td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="ke-stazeni.php">Ke sta�en�</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="https://vsevjednom.cz/guestbook.php?gb=30089&amp;lan=cs" target="_blank">Diskusn� kniha</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="linky.php">Odkazy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="center"><br><br>
          <!--Toplist-->
          <a href="http://www.toplist.cz/"><script language="JavaScript" type="text/javascript">
<!--
document.write ('<img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc&amp;http='+escape(document.referrer)+'&amp;wi='+escape(window.screen.width)+'&amp;he='+escape(window.screen.height)+'&amp;cd='+escape(window.screen.colorDepth)+'&amp;t='+escape(document.title)+'" width="88" height="120" border=0 alt="TOPlist" />');
//--></script></a><noscript><img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc" border="0"
alt="TOPlist" width="88" height="120"></noscript>
            <br><br><br>
            </td>
          </tr>

        </tbody></table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </tbody></table></td>
    <td class="rightMain" align="left"><table border="0" cellpadding="10" cellspacing="1" width="100%">
      
      <tbody><tr>
        <td class="forContent" align="center" valign="top"><!-- v�pis optosou��stek -->
<br>
<h1>LED, displeje, fototranzistory</h1>
<hr><br>
<table align="center" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="top" width="150">
<a href="10PN40.html">10PN40</a><br>
<a href="10PN41.html">10PN41</a><br>
<a href="10PP41.html">10PP41</a><br>
<a href="11PN41.html">11PN41</a><br>
<a href="11PP41.html">11PP41</a><br>
<a href="12PN41.html">12PN41</a><br>
<a href="12PP41.html">12PP41</a><br>
<a href="13PN41.html">13PN41</a><br>
<a href="1PP75.html">1PP75</a><br>
<a href="3WK16320.html">3WK16320</a><br>
<a href="3WK16321-1.html">3WK16321-1</a><br>
<a href="3WK16321-2.html">3WK16321-2</a><br>
<a href="3WK16331.html">3WK16331</a><br>
<a href="3WK16332.html">3WK16332</a><br>
<a href="3WK16406-1.html">3WK16406-1</a><br>
<a href="3WK16406-2.html">3WK16406-2</a><br>
<a href="3WK16407.html">3WK16407</a><br>
<a href="3WK16443.html">3WK16443</a><br>
<a href="3WK16444.html">3WK16444</a><br>
<a href="3WK16486.html">3WK16486</a><br>
<a href="3WN16605.html">3WN16605</a><br>
<a href="3WN16615.html">3WN16615</a><br>
<a href="3WN16616.html">3WN16616</a><br>
<a href="3WN16617.html">3WN16617</a><br>
<a href="3WN16619.html">3WN16619</a><br>
<a href="3WN16620.html">3WN16620</a><br>
<a href="3WN16623.html">3WN16623</a><br>
<a href="3WN16624.html">3WN16624</a><br>
<a href="4DR821.html">4DR821</a><br>
<a href="4DR821B.html">4DR821B</a><br>
<a href="4DR822.html">4DR822</a><br>
<a href="4DR822B.html">4DR822B</a><br>
<a href="4DS323A.html">4DS323A</a><br>
<a href="4DS323B.html">4DS323B</a><br>
<a href="4DT821.html">4DT821</a><br>
<a href="4DT821B.html">4DT821B</a><br>
<a href="4DT822.html">4DT822</a><br>
<a href="4DT822B.html">4DT822B</a><br>
<a href="DR401.html">DR401</a><br>
<a href="DR401B.html">DR401B</a><br>
<a href="DT401.html">DT401</a><br>
<a href="DT401B.html">DT401B</a><br>
<a href="KP101.html">KP101</a><br>
<a href="KP102.html">KP102</a><br>
<a href="KPX80.html">KPX80</a><br>
<a href="KPX81.html">KPX81</a><br>
<a href="KPX82.html">KPX82</a><br>
<a href="KPX83.html">KPX83</a><br>
<a href="KPX84.html">KPX84</a><br>
<a href="KPX85.html">KPX85</a><br>
<a href="KPX86.html">KPX86</a><br>
<a href="KPX87.html">KPX87</a><br>
<a href="KPX88.html">KPX88</a><br>
<a href="KPX89.html">KPX89</a><br>
<a href="LQ100.html">LQ100</a><br>
<a href="LQ110.html">LQ110</a><br>
<a href="LQ1101.html">LQ1101</a><br>
<a href="LQ1102.html">LQ1102</a><br>
<a href="LQ1103.html">LQ1103</a><br>

</td><td valign="top" width="150">
<a href="LQ1104.html">LQ1104</a><br>
<a href="LQ111.html">LQ111</a><br>
<a href="LQ1111.html">LQ1111</a><br>
<a href="LQ1112.html">LQ1112</a><br>
<a href="LQ1113.html">LQ1113</a><br>
<a href="LQ1114.html">LQ1114</a><br>
<a href="LQ112.html">LQ112</a><br>
<a href="LQ113.html">LQ113</a><br>
<a href="LQ1131.html">LQ1131</a><br>
<a href="LQ1132.html">LQ1132</a><br>
<a href="LQ1133.html">LQ1133</a><br>
<a href="LQ1134.html">LQ1134</a><br>
<a href="LQ114.html">LQ114</a><br>
<a href="LQ1202.html">LQ1202</a><br>
<a href="LQ1204.html">LQ1204</a><br>
<a href="LQ1212.html">LQ1212</a><br>
<a href="LQ1214.html">LQ1214</a><br>
<a href="LQ1401.html">LQ1401</a><br>
<a href="LQ1402.html">LQ1402</a><br>
<a href="LQ1403.html">LQ1403</a><br>
<a href="LQ1404.html">LQ1404</a><br>
<a href="LQ1411.html">LQ1411</a><br>
<a href="LQ1412.html">LQ1412</a><br>
<a href="LQ1413.html">LQ1413</a><br>
<a href="LQ1414.html">LQ1414</a><br>
<a href="LQ1431.html">LQ1431</a><br>
<a href="LQ1432.html">LQ1432</a><br>
<a href="LQ1433.html">LQ1433</a><br>
<a href="LQ1434.html">LQ1434</a><br>
<a href="LQ1502.html">LQ1502</a><br>
<a href="LQ1504.html">LQ1504</a><br>
<a href="LQ1512.html">LQ1512</a><br>
<a href="LQ1514.html">LQ1514</a><br>
<a href="LQ1701.html">LQ1701</a><br>
<a href="LQ1702.html">LQ1702</a><br>
<a href="LQ1703.html">LQ1703</a><br>
<a href="LQ1704.html">LQ1704</a><br>
<a href="LQ1711.html">LQ1711</a><br>
<a href="LQ1712.html">LQ1712</a><br>
<a href="LQ1713.html">LQ1713</a><br>
<a href="LQ1714.html">LQ1714</a><br>
<a href="LQ1731.html">LQ1731</a><br>
<a href="LQ1732.html">LQ1732</a><br>
<a href="LQ1733.html">LQ1733</a><br>
<a href="LQ1734.html">LQ1734</a><br>
<a href="LQ1802.html">LQ1802</a><br>
<a href="LQ1804.html">LQ1804</a><br>
<a href="LQ1812.html">LQ1812</a><br>
<a href="LQ1814.html">LQ1814</a><br>
<a href="LQ190.html">LQ190</a><br>
<a href="LQ2134.html">LQ2134</a><br>
<a href="LQ310.html">LQ310</a><br>
<a href="LQ340.html">LQ340</a><br>
<a href="LQ370.html">LQ370</a><br>
<a href="LQ410.html">LQ410</a><br>
<a href="LQ420.html">LQ420</a><br>
<a href="LQ440.html">LQ440</a><br>
<a href="LQ450.html">LQ450</a><br>
<a href="LQ470.html">LQ470</a><br>

</td><td valign="top" width="150">
<a href="LQ480.html">LQ480</a><br>
<a href="TY6220001.html">TY6220001</a><br>
<a href="TY6220002.html">TY6220002</a><br>
<a href="TY6220003.html">TY6220003</a><br>
<a href="TY6220005.html">TY6220005</a><br>
<a href="TY6220007.html">TY6220007</a><br>
<a href="TY6220010.html">TY6220010</a><br>
<a href="TY6220015.html">TY6220015</a><br>
<a href="TY6220020.html">TY6220020</a><br>
<a href="TY6220030.html">TY6220030</a><br>
<a href="TY6220050.html">TY6220050</a><br>
<a href="VQA15.html">VQA15</a><br>
<a href="VQA17.html">VQA17</a><br>
<a href="VQA25.html">VQA25</a><br>
<a href="VQA27.html">VQA27</a><br>
<a href="VQA35.html">VQA35</a><br>
<a href="VQA37.html">VQA37</a><br>
<a href="VQA47.html">VQA47</a><br>
<a href="VQB26.html">VQB26</a><br>
<a href="VQB28.html">VQB28</a><br>
<a href="VQB29.html">VQB29</a><br>
<a href="VQE11.html">VQE11</a><br>
<a href="VQE12.html">VQE12</a><br>
<a href="VQE13.html">VQE13</a><br>
<a href="VQE14.html">VQE14</a><br>
<a href="VQE21.html">VQE21</a><br>
<a href="VQE22.html">VQE22</a><br>
<a href="VQE23.html">VQE23</a><br>
<a href="VQE24.html">VQE24</a><br>
<a href="WK16402.html">WK16402</a><br>
<a href="WK16403.html">WK16403</a><br>
<a href="WK16412.html">WK16412</a><br>
<a href="WK16413.html">WK16413</a><br>
<a href="WK16414.html">WK16414</a><br>
<a href="WK16421.html">WK16421</a><br>
<a href="WK16422.html">WK16422</a><br>
<a href="WK16423.html">WK16423</a><br>
<a href="WK16424.html">WK16424</a><br>
<a href="WK16425.html">WK16425</a><br>
<a href="WK16426.html">WK16426</a><br>
<a href="WK16427.html">WK16427</a><br>
<a href="WK16428.html">WK16428</a><br>
<a href="WK16429.html">WK16429</a><br>
<a href="WK16430.html">WK16430</a><br>
<a href="WK65036A.html">WK65036A</a><br>
<a href="WK65037.html">WK65037</a><br>
<a href="WK65060A.html">WK65060A</a><br>
<a href="WK65061.html">WK65061</a><br>
<a href="WK65062.html">WK65062</a><br>
<a href="WK65065.html">WK65065</a><br>
<a href="WK65067.html">WK65067</a><br>
<a href="WK65070.html">WK65070</a><br>
<a href="WK65074.html">WK65074</a><br>
<a href="WK65075.html">WK65075</a><br>
<a href="WK65076.html">WK65076</a><br>
<a href="WK65077.html">WK65077</a><br>
<a href="WK65081.html">WK65081</a><br>

</td></tr>
<tr><td colspan="3">
<br><br>
pouzdra LED, diplej�, fototranzistor�: <a href="io0/op1.jpg">1</a>, <a href="io0/op2.jpg">2</a>, <a href="io0/op3.jpg">3</a>
</td></tr>
</tbody></table>
<br><br>

</td>
      </tr>
    
    </tbody></table></td>
  </tr>
</tbody></table>
</center></body></html>
