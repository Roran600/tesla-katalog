<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Rezistory, potenciometry</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<meta name="description" content="Katalog sou��stek - Rezistory, potenciometry - n�hrada str�nek io.freehosting.cz a io1.freehosting.cz a jejich dopln�n�">
<meta name="keywords" content="katalog, list, Tesla, rezistor, potenciometr">
<link href="stylcss.css" type="text/css" rel="stylesheet"></head><body>
<center>
<table border="0" cellpadding="4" cellspacing="2" width="800">
  <tbody><tr valign="top">

      <td class="leftMain" align="left" width="180"><table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>
        <td align="left" height="200" valign="top"><table border="0" cellpadding="3" cellspacing="1" width="100%">
          
          <tbody><tr>
            <td class="forMenu2" align="center" height="71" valign="middle"><br><br><a href="http://teslakatalog.cz"><img src="ikony/tesla_logo.gif" alt=" " border="0" height="116" width="112"></a><br><br><br></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="http://teslakatalog.cz">O webu</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="io.php">Integrovan� obvody</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tranzistor.php">Tranzistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tyristor-triak-diak.php">Tyristory, triaky</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="dioda-varikap.php">Diody, varikapy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="led-dispej-fototranzistor.php">Displeje, LED</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="kondenzator.php">Kondenz�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="rezistor.php">Rezistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tlumivka.php">Tlumivky, filtry</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="xtal.php">Krystaly, oscil�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="termistor.php">Termistory Pramet</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle">&nbsp;</td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="ke-stazeni.php">Ke sta�en�</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="https://vsevjednom.cz/guestbook.php?gb=30089&amp;lan=cs" target="_blank">Diskusn� kniha</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="linky.php">Odkazy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="center"><br><br>
          <!--Toplist-->
          <a href="http://www.toplist.cz/"><script language="JavaScript" type="text/javascript">
<!--
document.write ('<img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc&amp;http='+escape(document.referrer)+'&amp;wi='+escape(window.screen.width)+'&amp;he='+escape(window.screen.height)+'&amp;cd='+escape(window.screen.colorDepth)+'&amp;t='+escape(document.title)+'" width="88" height="120" border=0 alt="TOPlist" />');
//--></script></a><noscript><img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc" border="0"
alt="TOPlist" width="88" height="120"></noscript>
            <br><br><br>
            </td>
          </tr>

        </tbody></table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </tbody></table></td>
    <td class="rightMain" align="left"><table border="0" cellpadding="10" cellspacing="1" width="100%">
      
      <tbody><tr>
        <td class="forContent" align="center" valign="top"><!-- v�pis rezistor� -->
<br>
<h1>Rezistory, potenciometry</h1>
<hr><br>
<table align="center" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr><td valign="top" width="150">
<a href="MLT-0-25.html">MLT-0,25</a><br>
<a href="MLT-0-5.html">MLT-0,5</a><br>
<a href="MLT-1-0.html">MLT-1,0</a><br>
<a href="MLT-2-0.html">MLT-2,0</a><br>
<a href="PEVR-10.html">PEVR-10</a><br>
<a href="PEVR-15.html">PEVR-15</a><br>
<a href="PEVR-25.html">PEVR-25</a><br>
<a href="PEV-10.html">PEV-10</a><br>
<a href="PEV-15.html">PEV-15</a><br>
<a href="PEV-25.html">PEV-25</a><br>
<a href="PNC10CB.html">PNC10CB</a><br>
<a href="PNC11CB.html">PNC11CB</a><br>
<a href="SWV141.html">SWV141</a><br>
<a href="SWV142.html">SWV142</a><br>
<a href="SWV143.html">SWV143</a><br>
<a href="TP005.html">TP005</a><br>
<a href="TP008.html">TP008</a><br>
<a href="TP009.html">TP009</a><br>
<a href="TP011.html">TP011</a><br>
<a href="TP012.html">TP012</a><br>
<a href="TP015.html">TP015</a><br>
<a href="TP016.html">TP016</a><br>
<a href="TP017.html">TP017</a><br>
<a href="TP018.html">TP018</a><br>
<a href="TP025.html">TP025</a><br>
<a href="TP026.html">TP026</a><br>
<a href="TP040.html">TP040</a><br>
<a href="TP041.html">TP041</a><br>
<a href="TP042.html">TP042</a><br>
<a href="TP045.html">TP045</a><br>
<a href="TP046.html">TP046</a><br>
<a href="TP047.html">TP047</a><br>
<a href="TP048.html">TP048</a><br>
<a href="TP049.html">TP049</a><br>
<a href="TP052c.html">TP052c</a><br>
<a href="TP060.html">TP060</a><br>
<a href="TP062.html">TP062</a><br>
<a href="TP095.html">TP095</a><br>
<a href="TP096.html">TP096</a><br>
<a href="TP100.html">TP100</a><br>
<a href="TP110.html">TP110</a><br>
<a href="TP111.html">TP111</a><br>
<a href="TP112.html">TP112</a><br>
<a href="TP113.html">TP113</a><br>
<a href="TP160.html">TP160</a><br>
<a href="TP160A.html">TP160A</a><br>
<a href="TP160D.html">TP160D</a><br>
<a href="TP160P.html">TP160P</a><br>
<a href="TP161.html">TP161</a><br>
<a href="TP161A.html">TP161A</a><br>
<a href="TP161D.html">TP161D</a><br>
<a href="TP161P.html">TP161P</a><br>
<a href="TP162.html">TP162</a><br>
<a href="TP162A.html">TP162A</a><br>
<a href="TP163.html">TP163</a><br>
<a href="TP163A.html">TP163A</a><br>
<a href="TP164.html">TP164</a><br>
<a href="TP164A.html">TP164A</a><br>
<a href="TP166.html">TP166</a><br>
<a href="TP166A.html">TP166A</a><br>
<a href="TP169.html">TP169</a><br>
<a href="TP169A.html">TP169A</a><br>
<a href="TP190.html">TP190</a><br>
<a href="TP195.html">TP195</a><br>
<a href="TP199.html">TP199</a><br>
<a href="TP280b.html">TP280b</a><br>
<a href="TP280n.html">TP280n</a><br>
<a href="TP281b.html">TP281b</a><br>

</td><td valign="top" width="150">
<a href="TP281n.html">TP281n</a><br>
<a href="TP283b.html">TP283b</a><br>
<a href="TP283n.html">TP283n</a><br>
<a href="TP286b.html">TP286b</a><br>
<a href="TP286n.html">TP286n</a><br>
<a href="TP287b.html">TP287b</a><br>
<a href="TP287n.html">TP287n</a><br>
<a href="TP289D.html">TP289D</a><br>
<a href="TP600.html">TP600</a><br>
<a href="TP601.html">TP601</a><br>
<a href="TP605.html">TP605</a><br>
<a href="TP606.html">TP606</a><br>
<a href="TP610.html">TP610</a><br>
<a href="TP620.html">TP620</a><br>
<a href="TP640.html">TP640</a><br>
<a href="TP642.html">TP642</a><br>
<a href="TP645.html">TP645</a><br>
<a href="TP646.html">TP646</a><br>
<a href="TP650.html">TP650</a><br>
<a href="TP655.html">TP655</a><br>
<a href="TP656.html">TP656</a><br>
<a href="TP680.html">TP680</a><br>
<a href="TRP006.html">TRP006</a><br>
<a href="TRP106.html">TRP106</a><br>
<a href="TR130.html">TR130</a><br>
<a href="TR131.html">TR131</a><br>
<a href="TR142.html">TR142</a><br>
<a href="TR157.html">TR157</a><br>
<a href="TR161.html">TR161</a><br>
<a href="TR163.html">TR163</a><br>
<a href="TR164.html">TR164</a><br>
<a href="TR191.html">TR191</a><br>
<a href="TR192.html">TR192</a><br>
<a href="TR193.html">TR193</a><br>
<a href="TR194.html">TR194</a><br>
<a href="TR196.html">TR196</a><br>
<a href="TR211.html">TR211</a><br>
<a href="TR212.html">TR212</a><br>
<a href="TR213.html">TR213</a><br>
<a href="TR214.html">TR214</a><br>
<a href="TR215.html">TR215</a><br>
<a href="TR216.html">TR216</a><br>
<a href="TR217.html">TR217</a><br>
<a href="TR221.html">TR221</a><br>
<a href="TR223.html">TR223</a><br>
<a href="TR224.html">TR224</a><br>
<a href="TR225.html">TR225</a><br>
<a href="TR226.html">TR226</a><br>
<a href="TR232.html">TR232</a><br>
<a href="TR232A.html">TR232A</a><br>
<a href="TR232B.html">TR232B</a><br>
<a href="TR233.html">TR233</a><br>
<a href="TR233P.html">TR233P</a><br>
<a href="TR234.html">TR234</a><br>
<a href="TR234P.html">TR234P</a><br>
<a href="TR235.html">TR235</a><br>
<a href="TR235P.html">TR235P</a><br>
<a href="TR236.html">TR236</a><br>
<a href="TR236P.html">TR236P</a><br>
<a href="TR243.html">TR243</a><br>
<a href="TR296.html">TR296</a><br>
<a href="TR507.html">TR507</a><br>
<a href="TR508.html">TR508</a><br>
<a href="TR509.html">TR509</a><br>
<a href="TR510.html">TR510</a><br>
<a href="TR511.html">TR511</a><br>
<a href="TR512.html">TR512</a><br>
<a href="TR520.html">TR520</a><br>

</td><td valign="top" width="150">
<a href="TR521.html">TR521</a><br>
<a href="TR522.html">TR522</a><br>
<a href="TR523.html">TR523</a><br>
<a href="TR524.html">TR524</a><br>
<a href="TR551.html">TR551</a><br>
<a href="TR552.html">TR552</a><br>
<a href="TR553.html">TR553</a><br>
<a href="TR556.html">TR556</a><br>
<a href="TR557.html">TR557</a><br>
<a href="TR558.html">TR558</a><br>
<a href="TR600.html">TR600</a><br>
<a href="TR602.html">TR602</a><br>
<a href="TR603.html">TR603</a><br>
<a href="TR616.html">TR616</a><br>
<a href="TR617.html">TR617</a><br>
<a href="TR618.html">TR618</a><br>
<a href="TR619.html">TR619</a><br>
<a href="TR620.html">TR620</a><br>
<a href="TR621.html">TR621</a><br>
<a href="TR622.html">TR622</a><br>
<a href="TR623.html">TR623</a><br>
<a href="TR624.html">TR624</a><br>
<a href="TR626.html">TR626</a><br>
<a href="TR627.html">TR627</a><br>
<a href="TR628.html">TR628</a><br>
<a href="TR629.html">TR629</a><br>
<a href="TR630.html">TR630</a><br>
<a href="TR645.html">TR645</a><br>
<a href="TR646.html">TR646</a><br>
<a href="TR647.html">TR647</a><br>
<a href="TR648.html">TR648</a><br>
<a href="TR649.html">TR649</a><br>
<a href="TR650.html">TR650</a><br>
<a href="TR651.html">TR651</a><br>
<a href="TR652.html">TR652</a><br>
<a href="TR655.html">TR655</a><br>
<a href="TR656.html">TR656</a><br>
<a href="TR657.html">TR657</a><br>
<a href="TR658.html">TR658</a><br>
<a href="WK65005.html">WK65005</a><br>
<a href="WK66936.html">WK66936</a><br>
<a href="WK66937.html">WK66937</a><br>
<a href="WK66944.html">WK66944</a><br>
<a href="WK66945.html">WK66945</a><br>
<a href="WK66946.html">WK66946</a><br>
<a href="WK66950.html">WK66950</a><br>
<a href="WK66951.html">WK66951</a><br>
<a href="WK66952.html">WK66952</a><br>
<a href="WK67911.html">WK67911</a><br>
<a href="WK67912.html">WK67912</a><br>
<a href="WK68191.html">WK68191</a><br>
<a href="WK68192.html">WK68192</a><br>
<a href="WK68193.html">WK68193</a><br>
<a href="WK68194.html">WK68194</a><br>
<a href="WN69010.html">WN69010</a><br>
<a href="WN69040.html">WN69040</a><br>
<a href="WN69050.html">WN69050</a><br>
<a href="WN69170.html">WN69170</a><br>
<a href="WN69185.html">WN69185</a><br>
<a href="WN69802.html">WN69802</a><br>
<a href="WN79010.html">WN79010</a><br>
<a href="WN79031.html">WN79031</a><br>
<a href="3WF68181.html">3WF68181</a><br>
<a href="3WF68182.html">3WF68182</a><br>
<a href="3WK68104.html">3WK68104</a><br>
<a href="3WK68105.html">3WK68105</a><br>
<a href="3WK68131.html">3WK68131</a><br>

</td></tr>
</tbody></table>
<br><br>

</td>
      </tr>
    
    </tbody></table></td>
  </tr>
</tbody></table>
</center></body></html>
