<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Tranzistory</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<meta name="description" content="Katalog sou��stek - tranzistory - n�hrada str�nek io.freehosting.cz a io1.freehosting.cz a jejich dopln�n�">
<meta name="keywords" content="katalog, list, Tesla, tranzistor">
<link href="stylcss.css" type="text/css" rel="stylesheet"></head><body>
<center>
<table border="0" cellpadding="4" cellspacing="2" width="800">
  <tbody><tr valign="top">

      <td class="leftMain" align="left" width="180"><table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>
        <td align="left" height="200" valign="top"><table border="0" cellpadding="3" cellspacing="1" width="100%">
          
          <tbody><tr>
            <td class="forMenu2" align="center" height="71" valign="middle"><br><br><a href="http://teslakatalog.cz"><img src="ikony/tesla_logo.gif" alt=" " border="0" height="116" width="112"></a><br><br><br></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="http://teslakatalog.cz">O webu</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="io.php">Integrovan� obvody</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tranzistor.php">Tranzistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tyristor-triak-diak.php">Tyristory, triaky</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="dioda-varikap.php">Diody, varikapy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="led-dispej-fototranzistor.php">Displeje, LED</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="kondenzator.php">Kondenz�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="rezistor.php">Rezistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tlumivka.php">Tlumivky, filtry</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="xtal.php">Krystaly, oscil�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="termistor.php">Termistory Pramet</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle">&nbsp;</td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="ke-stazeni.php">Ke sta�en�</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="https://vsevjednom.cz/guestbook.php?gb=30089&amp;lan=cs" target="_blank">Diskusn� kniha</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="linky.php">Odkazy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="center"><br><br>
          <!--Toplist-->
          <a href="http://www.toplist.cz/"><script language="JavaScript" type="text/javascript">
<!--
document.write ('<img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc&amp;http='+escape(document.referrer)+'&amp;wi='+escape(window.screen.width)+'&amp;he='+escape(window.screen.height)+'&amp;cd='+escape(window.screen.colorDepth)+'&amp;t='+escape(document.title)+'" width="88" height="120" border=0 alt="TOPlist" />');
//--></script></a><noscript><img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc" border="0"
alt="TOPlist" width="88" height="120"></noscript>
            <br><br><br>
            </td>
          </tr>

        </tbody></table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </tbody></table></td>
    <td class="rightMain" align="left"><table border="0" cellpadding="10" cellspacing="1" width="100%">
      
      <tbody><tr>
        <td class="forContent" align="center" valign="top"><!-- v�pis tranzistor� -->
<br>
<h1>Tranzistory</h1>
<hr><br>
<table class="forContent" align="center" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="top" width="150">
<a href="101NU70.html">101NU70</a><br>
<a href="101NU71.html">101NU71</a><br>
<a href="102NU70.html">102NU70</a><br>
<a href="102NU71.html">102NU71</a><br>
<a href="102NU71-transimat.html">102NU71 transimat</a><br>
<a href="103NU70.html">103NU70</a><br>
<a href="103NU71.html">103NU71</a><br>
<a href="104NU70.html">104NU70</a><br>
<a href="104NU71.html">104NU71</a><br>
<a href="105NU70.html">105NU70</a><br>
<a href="105NU70-bily.html">105NU70 b�l�</a><br>
<a href="106NU70.html">106NU70</a><br>
<a href="106NU70-bily.html">106NU70 b�l�</a><br>
<a href="107NU70.html">107NU70</a><br>
<a href="107NU70-bily.html">107NU70 b�l�</a><br>
<a href="152NU70.html">152NU70</a><br>
<a href="153NU70.html">153NU70</a><br>
<a href="154NU70.html">154NU70</a><br>
<a href="155NU70.html">155NU70</a><br>
<a href="156NU70.html">156NU70</a><br>
<a href="2NU72.html">2NU72</a><br>
<a href="2NU73.html">2NU73</a><br>
<a href="2NU74.html">2NU74</a><br>
<a href="3NU72.html">3NU72</a><br>
<a href="3NU73.html">3NU73</a><br>
<a href="3NU74.html">3NU74</a><br>
<a href="4NU72.html">4NU72</a><br>
<a href="4NU73.html">4NU73</a><br>
<a href="4NU74.html">4NU74</a><br>
<a href="5NU72.html">5NU72</a><br>
<a href="5NU73.html">5NU73</a><br>
<a href="5NU74.html">5NU74</a><br>
<a href="6NU73.html">6NU73</a><br>
<a href="6NU74.html">6NU74</a><br>
<a href="7NU73.html">7NU73</a><br>
<a href="7NU74.html">7NU74</a><br>
<a href="8342-1.html">8342-1</a><br>
<a href="8342-2.html">8342-2</a><br>
<a href="AD161.html">AD161</a><br>
<a href="AD162.html">AD162</a><br>
<a href="BC157A.html">BC157A</a><br>
<a href="BC157V.html">BC157V</a><br>
<a href="BC158A.html">BC158A</a><br>
<a href="BC158B.html">BC158B</a><br>
<a href="BC158VI.html">BC158VI</a><br>
<a href="BC159A.html">BC159A</a><br>
<a href="BC159B.html">BC159B</a><br>
<a href="BC177A.html">BC177A</a><br>
<a href="BC177B.html">BC177B</a><br>
<a href="BC177V.html">BC177V</a><br>
<a href="BC177VI.html">BC177VI</a><br>
<a href="BC178A.html">BC178A</a><br>
<a href="BC178B.html">BC178B</a><br>
<a href="BC178V.html">BC178V</a><br>
<a href="BC178VI.html">BC178VI</a><br>
<a href="BC179A.html">BC179A</a><br>
<a href="BC179B.html">BC179B</a><br>
<a href="BC211.html">BC211</a><br>
<a href="BC313.html">BC313</a><br>
<a href="BC413B.html">BC413B</a><br>
<a href="BC413C.html">BC413C</a><br>
<a href="BD354.html">BD354</a><br>
<a href="BD355.html">BD355</a><br>
<a href="BF167.html">BF167</a><br>
<a href="BF173.html">BF173</a><br>
<a href="BF257.html">BF257</a><br>
<a href="BF258.html">BF258</a><br>
<a href="BF259.html">BF259</a><br>
<a href="BF457.html">BF457</a><br>
<a href="BF458.html">BF458</a><br>
<a href="BF459.html">BF459</a><br>
<a href="BSX29.html">BSX29</a><br>
<a href="BSX59.html">BSX59</a><br>
<a href="BSX60.html">BSX60</a><br>
<a href="BSX61.html">BSX61</a><br>
<a href="BSY34.html">BSY34</a><br>
<a href="GC500.html">GC500</a><br>
<a href="GC501.html">GC501</a><br>
<a href="GC502.html">GC502</a><br>
<a href="GC507.html">GC507</a><br>
<a href="GC508.html">GC508</a><br>
<a href="GC509.html">GC509</a><br>
<a href="GC510.html">GC510</a><br>
<a href="GC510K.html">GC510K</a><br>
<a href="GC511.html">GC511</a><br>
<a href="GC511K.html">GC511K</a><br>
<a href="GC512.html">GC512</a><br>
<a href="GC512K.html">GC512K</a><br>
<a href="GC515.html">GC515</a><br>
<a href="GC516.html">GC516</a><br>
<a href="GC517.html">GC517</a><br>
<a href="GC518.html">GC518</a><br>
<a href="GC519.html">GC519</a><br>
<a href="GC520.html">GC520</a><br>
<a href="GC520K.html">GC520K</a><br>
<a href="GC521.html">GC521</a><br>
<a href="GC521K.html">GC521K</a><br>
<a href="GC522.html">GC522</a><br>
<a href="GC522K.html">GC522K</a><br>
<a href="GD601.html">GD601</a><br>
<a href="GD602.html">GD602</a><br>
<a href="GD603.html">GD603</a><br>
<a href="GD604.html">GD604</a><br>
<a href="GD607.html">GD607</a><br>
<a href="GD608.html">GD608</a><br>
<a href="GD609.html">GD609</a><br>
<a href="GD617.html">GD617</a><br>
<a href="GD618.html">GD618</a><br>
<a href="GD619.html">GD619</a><br>
<a href="GF501.html">GF501</a><br>
<a href="GF502.html">GF502</a><br>
<a href="GF504.html">GF504</a><br>
<a href="GF505.html">GF505</a><br>
<a href="GF506.html">GF506</a><br>
<a href="GF507.html">GF507</a><br>
<a href="GS501.html">GS501</a><br>
<a href="GS502.html">GS502</a><br>
<a href="GS504.html">GS504</a><br>
<a href="GS506.html">GS506</a><br>
<a href="GS507.html">GS507</a><br>
<a href="GS508.html">GS508</a><br>
<a href="GT322.html">GT322</a><br>
<a href="GT322A.html">GT322A</a><br>
<a href="GT328A.html">GT328A</a><br>
<a href="GT328B.html">GT328B</a><br>
<a href="GT346A.html">GT346A</a><br>
<a href="GT346B.html">GT346B</a><br>
<a href="GT346V.html">GT346V</a><br>
<a href="KC147.html">KC147</a><br>
<a href="KC148.html">KC148</a><br>
<a href="KC149.html">KC149</a><br>
<a href="KC237-1D.html">KC237-1D</a><br>
<a href="KC237A.html">KC237A</a><br>
<a href="KC237B.html">KC237B</a><br>
<a href="KC237V.html">KC237V</a><br>
<a href="KC238-1E.html">KC238-1E</a><br>
<a href="KC238A.html">KC238A</a><br>

</td><td valign="top" width="150">
<a href="KC238B.html">KC238B</a><br>
<a href="KC238C.html">KC238C</a><br>
<a href="KC239-1H.html">KC239-1H</a><br>
<a href="KC239B.html">KC239B</a><br>
<a href="KC239C.html">KC239C</a><br>
<a href="KC239E.html">KC239E</a><br>
<a href="KC239F.html">KC239F</a><br>
<a href="KC307A.html">KC307A</a><br>
<a href="KC307B.html">KC307B</a><br>
<a href="KC307V.html">KC307V</a><br>
<a href="KC308A.html">KC308A</a><br>
<a href="KC308B.html">KC308B</a><br>
<a href="KC308C.html">KC308C</a><br>
<a href="KC309B.html">KC309B</a><br>
<a href="KC309C.html">KC309C</a><br>
<a href="KC309F.html">KC309F</a><br>
<a href="KC507.html">KC507</a><br>
<a href="KC508.html">KC508</a><br>
<a href="KC509.html">KC509</a><br>
<a href="KC510.html">KC510</a><br>
<a href="KC635.html">KC635</a><br>
<a href="KC636.html">KC636</a><br>
<a href="KC637.html">KC637</a><br>
<a href="KC638.html">KC638</a><br>
<a href="KC639.html">KC639</a><br>
<a href="KC640.html">KC640</a><br>
<a href="KC809.html">KC809</a><br>
<a href="KC810.html">KC810</a><br>
<a href="KC811.html">KC811</a><br>
<a href="KC812.html">KC812</a><br>
<a href="KCJ10.html">KCJ10</a><br>
<a href="KCY33.html">KCY33</a><br>
<a href="KCY34.html">KCY34</a><br>
<a href="KCY35.html">KCY35</a><br>
<a href="KCY36.html">KCY36</a><br>
<a href="KCY37.html">KCY37</a><br>
<a href="KCY38.html">KCY38</a><br>
<a href="KCY39.html">KCY39</a><br>
<a href="KCY40.html">KCY40</a><br>
<a href="KCZ58.html">KCZ58</a><br>
<a href="KCZ59.html">KCZ59</a><br>
<a href="KD135.html">KD135</a><br>
<a href="KD136.html">KD136</a><br>
<a href="KD137.html">KD137</a><br>
<a href="KD138.html">KD138</a><br>
<a href="KD139.html">KD139</a><br>
<a href="KD140.html">KD140</a><br>
<a href="KD15003.html">KD15003</a><br>
<a href="KD15004.html">KD15004</a><br>
<a href="KD237.html">KD237</a><br>
<a href="KD237A.html">KD237A</a><br>
<a href="KD237AT.html">KD237AT</a><br>
<a href="KD237T.html">KD237T</a><br>
<a href="KD238.html">KD238</a><br>
<a href="KD238A.html">KD238A</a><br>
<a href="KD238AT.html">KD238AT</a><br>
<a href="KD238T.html">KD238T</a><br>
<a href="KD239B.html">KD239B</a><br>
<a href="KD239C.html">KD239C</a><br>
<a href="KD240B.html">KD240B</a><br>
<a href="KD240C.html">KD240C</a><br>
<a href="KD270.html">KD270</a><br>
<a href="KD270A.html">KD270A</a><br>
<a href="KD271.html">KD271</a><br>
<a href="KD271A.html">KD271A</a><br>
<a href="KD2955.html">KD2955</a><br>
<a href="KD3055.html">KD3055</a><br>
<a href="KD3055P.html">KD3055P</a><br>
<a href="KD333.html">KD333</a><br>
<a href="KD334.html">KD334</a><br>
<a href="KD335.html">KD335</a><br>
<a href="KD336.html">KD336</a><br>
<a href="KD337.html">KD337</a><br>
<a href="KD338.html">KD338</a><br>
<a href="KD3442.html">KD3442</a><br>
<a href="KD3442T.html">KD3442T</a><br>
<a href="KD366.html">KD366</a><br>
<a href="KD366A.html">KD366A</a><br>
<a href="KD366B.html">KD366B</a><br>
<a href="KD367.html">KD367</a><br>
<a href="KD367A.html">KD367A</a><br>
<a href="KD367B.html">KD367B</a><br>
<a href="KD3772.html">KD3772</a><br>
<a href="KD3773.html">KD3773</a><br>
<a href="KD3773T.html">KD3773T</a><br>
<a href="KD4348.html">KD4348</a><br>
<a href="KD501.html">KD501</a><br>
<a href="KD502.html">KD502</a><br>
<a href="KD503.html">KD503</a><br>
<a href="KD5302.html">KD5302</a><br>
<a href="KD5303.html">KD5303</a><br>
<a href="KD5745.html">KD5745</a><br>
<a href="KD601.html">KD601</a><br>
<a href="KD602.html">KD602</a><br>
<a href="KD605.html">KD605</a><br>
<a href="KD606.html">KD606</a><br>
<a href="KD607.html">KD607</a><br>
<a href="KD615.html">KD615</a><br>
<a href="KD616.html">KD616</a><br>
<a href="KD617.html">KD617</a><br>
<a href="KD649.html">KD649</a><br>
<a href="KD649A.html">KD649A</a><br>
<a href="KD649AT.html">KD649AT</a><br>
<a href="KD649B.html">KD649B</a><br>
<a href="KD649BT.html">KD649BT</a><br>
<a href="KD649T.html">KD649T</a><br>
<a href="KD650.html">KD650</a><br>
<a href="KD650A.html">KD650A</a><br>
<a href="KD650AT.html">KD650AT</a><br>
<a href="KD650B.html">KD650B</a><br>
<a href="KD650BT.html">KD650BT</a><br>
<a href="KD650T.html">KD650T</a><br>
<a href="KD711.html">KD711</a><br>
<a href="KD711T.html">KD711T</a><br>
<a href="KD712.html">KD712</a><br>
<a href="KD712T.html">KD712T</a><br>
<a href="KDY23.html">KDY23</a><br>
<a href="KDY24.html">KDY24</a><br>
<a href="KDY25.html">KDY25</a><br>
<a href="KDY26.html">KDY26</a><br>
<a href="KDY56.html">KDY56</a><br>
<a href="KDY73.html">KDY73</a><br>
<a href="KDY74.html">KDY74</a><br>
<a href="KDY76.html">KDY76</a><br>
<a href="KF124.html">KF124</a><br>
<a href="KF125.html">KF125</a><br>
<a href="KF167.html">KF167</a><br>
<a href="KF173.html">KF173</a><br>
<a href="KF189.html">KF189</a><br>
<a href="KF190.html">KF190</a><br>

</td><td valign="top" width="150">
<a href="KF223.html">KF223</a><br>
<a href="KF254.html">KF254</a><br>
<a href="KF255.html">KF255</a><br>
<a href="KF257.html">KF257</a><br>
<a href="KF258.html">KF258</a><br>
<a href="KF272.html">KF272</a><br>
<a href="KF422.html">KF422</a><br>
<a href="KF422X.html">KF422X</a><br>
<a href="KF423.html">KF423</a><br>
<a href="KF423X.html">KF423X</a><br>
<a href="KF469.html">KF469</a><br>
<a href="KF470.html">KF470</a><br>
<a href="KF503.html">KF503</a><br>
<a href="KF504.html">KF504</a><br>
<a href="KF506.html">KF506</a><br>
<a href="KF507.html">KF507</a><br>
<a href="KF508.html">KF508</a><br>
<a href="KF508A.html">KF508A</a><br>
<a href="KF509.html">KF509</a><br>
<a href="KF517.html">KF517</a><br>
<a href="KF517A.html">KF517A</a><br>
<a href="KF517B.html">KF517B</a><br>
<a href="KF517C.html">KF517C</a><br>
<a href="KF520.html">KF520</a><br>
<a href="KF521.html">KF521</a><br>
<a href="KF522.html">KF522</a><br>
<a href="KF523.html">KF523</a><br>
<a href="KF524.html">KF524</a><br>
<a href="KF525.html">KF525</a><br>
<a href="KF552.html">KF552</a><br>
<a href="KF589.html">KF589</a><br>
<a href="KF590.html">KF590</a><br>
<a href="KF621.html">KF621</a><br>
<a href="KF622.html">KF622</a><br>
<a href="KF630A.html">KF630A</a><br>
<a href="KF630B.html">KF630B</a><br>
<a href="KF630C.html">KF630C</a><br>
<a href="KF630D.html">KF630D</a><br>
<a href="KF630S.html">KF630S</a><br>
<a href="KF907.html">KF907</a><br>
<a href="KF910.html">KF910</a><br>
<a href="KF964.html">KF964</a><br>
<a href="KF966.html">KF966</a><br>
<a href="KF982.html">KF982</a><br>
<a href="KFW16A.html">KFW16A</a><br>
<a href="KFW17A.html">KFW17A</a><br>
<a href="KFY16.html">KFY16</a><br>
<a href="KFY18.html">KFY18</a><br>
<a href="KFY34.html">KFY34</a><br>
<a href="KFY46.html">KFY46</a><br>
<a href="KS4391.html">KS4391</a><br>
<a href="KS4392.html">KS4392</a><br>
<a href="KS4393.html">KS4393</a><br>
<a href="KS500.html">KS500</a><br>
<a href="KSN05.html">KSN05</a><br>
<a href="KSN10.html">KSN10</a><br>
<a href="KSN20.html">KSN20</a><br>
<a href="KSN40.html">KSN40</a><br>
<a href="KSY21.html">KSY21</a><br>
<a href="KSY34.html">KSY34</a><br>
<a href="KSY34D.html">KSY34D</a><br>
<a href="KSY62.html">KSY62</a><br>
<a href="KSY62A.html">KSY62A</a><br>
<a href="KSY62B.html">KSY62B</a><br>
<a href="KSY63.html">KSY63</a><br>
<a href="KSY71.html">KSY71</a><br>
<a href="KSY72.html">KSY72</a><br>
<a href="KSY81.html">KSY81</a><br>
<a href="KSY82.html">KSY82</a><br>
<a href="KSZ62.html">KSZ62</a><br>
<a href="KU3767P.html">KU3767P</a><br>
<a href="KU3767T.html">KU3767T</a><br>
<a href="KU601.html">KU601</a><br>
<a href="KU602.html">KU602</a><br>
<a href="KU605.html">KU605</a><br>
<a href="KU606.html">KU606</a><br>
<a href="KU607.html">KU607</a><br>
<a href="KU607P.html">KU607P</a><br>
<a href="KU607T.html">KU607T</a><br>
<a href="KU608.html">KU608</a><br>
<a href="KU608T.html">KU608T</a><br>
<a href="KU611.html">KU611</a><br>
<a href="KU612.html">KU612</a><br>
<a href="KU921.html">KU921</a><br>
<a href="KU921P.html">KU921P</a><br>
<a href="KU922.html">KU922</a><br>
<a href="KUN05.html">KUN05</a><br>
<a href="KUN10.html">KUN10</a><br>
<a href="KUN101.html">KUN101</a><br>
<a href="KUN20.html">KUN20</a><br>
<a href="KUN40.html">KUN40</a><br>
<a href="KUV41.html">KUV41</a><br>
<a href="KUV41N.html">KUV41N</a><br>
<a href="KUV60.html">KUV60</a><br>
<a href="KUV61.html">KUV61</a><br>
<a href="KUX41N.html">KUX41N</a><br>
<a href="KUY12.html">KUY12</a><br>
<a href="KUY12T.html">KUY12T</a><br>
<a href="OC169.html">OC169</a><br>
<a href="OC170.html">OC170</a><br>
<a href="OC170-vkv.html">OC170 vkv</a><br>
<a href="OC26.html">OC26</a><br>
<a href="OC27.html">OC27</a><br>
<a href="OC30.html">OC30</a><br>
<a href="OC70.html">OC70</a><br>
<a href="OC71.html">OC71</a><br>
<a href="OC72.html">OC72</a><br>
<a href="OC75.html">OC75</a><br>
<a href="OC76.html">OC76</a><br>
<a href="OC77.html">OC77</a><br>
<a href="P13.html">P13</a><br>
<a href="P13A.html">P13A</a><br>
<a href="P13B.html">P13B</a><br>
<a href="P14.html">P14</a><br>
<a href="SF240.html">SF240</a><br>
<a href="SF245.html">SF245</a><br>
<a href="SF357.html">SF357</a><br>
<a href="SF358.html">SF358</a><br>
<a href="SF359.html">SF359</a><br>
<a href="SU160.html">SU160</a><br>
<a href="SU161.html">SU161</a><br>
<a href="SU167.html">SU167</a><br>
<a href="SU169.html">SU169</a><br>
<a href="TR12.html">TR12</a><br>
<a href="TR13.html">TR13</a><br>
<a href="TR15.html">TR15</a><br>
<a href="TR18.html">TR18</a><br>
<a href="TR23.html">TR23</a><br>

</td></tr>
<tr><td colspan="3">
<br><br>
pouzdra tranzistor�: <a href="io0/tp1.jpg">1</a>, <a href="io0/tp2.jpg">2</a>, <a href="io0/tp3.jpg">3</a>
</td></tr>
</tbody></table>
<br><br>

</td>
      </tr>
    
    </tbody></table></td>
  </tr>
</tbody></table>
</center></body></html>
