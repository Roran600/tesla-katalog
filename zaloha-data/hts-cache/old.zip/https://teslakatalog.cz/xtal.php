<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Rezistory, potenciometry</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<meta name="description" content="Katalog sou��stek - Krystaly, oscil�tory - n�hrada str�nek io.freehosting.cz a io1.freehosting.cz a jejich dopln�n�">
<meta name="keywords" content="katalog, list, Tesla, krystal, oscil�tor">
<link href="stylcss.css" type="text/css" rel="stylesheet"></head><body>
<center>
<table border="0" cellpadding="4" cellspacing="2" width="800">
  <tbody><tr valign="top">

      <td class="leftMain" align="left" width="180"><table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>
        <td align="left" height="200" valign="top"><table border="0" cellpadding="3" cellspacing="1" width="100%">
          
          <tbody><tr>
            <td class="forMenu2" align="center" height="71" valign="middle"><br><br><a href="http://teslakatalog.cz"><img src="ikony/tesla_logo.gif" alt=" " border="0" height="116" width="112"></a><br><br><br></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="http://teslakatalog.cz">O webu</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="io.php">Integrovan� obvody</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tranzistor.php">Tranzistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tyristor-triak-diak.php">Tyristory, triaky</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="dioda-varikap.php">Diody, varikapy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="led-dispej-fototranzistor.php">Displeje, LED</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="kondenzator.php">Kondenz�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="rezistor.php">Rezistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tlumivka.php">Tlumivky, filtry</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="xtal.php">Krystaly, oscil�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="termistor.php">Termistory Pramet</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle">&nbsp;</td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="ke-stazeni.php">Ke sta�en�</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="https://vsevjednom.cz/guestbook.php?gb=30089&amp;lan=cs" target="_blank">Diskusn� kniha</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="linky.php">Odkazy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="center"><br><br>
          <!--Toplist-->
          <a href="http://www.toplist.cz/"><script language="JavaScript" type="text/javascript">
<!--
document.write ('<img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc&amp;http='+escape(document.referrer)+'&amp;wi='+escape(window.screen.width)+'&amp;he='+escape(window.screen.height)+'&amp;cd='+escape(window.screen.colorDepth)+'&amp;t='+escape(document.title)+'" width="88" height="120" border=0 alt="TOPlist" />');
//--></script></a><noscript><img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc" border="0"
alt="TOPlist" width="88" height="120"></noscript>
            <br><br><br>
            </td>
          </tr>

        </tbody></table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </tbody></table></td>
    <td class="rightMain" align="left"><table border="0" cellpadding="10" cellspacing="1" width="100%">
      
      <tbody><tr>
        <td class="forContent" align="center" valign="top"><!-- v�pis krystal�, oscil�tor� -->
<br>
<h1>Krystaly, oscil�tory</h1>
<hr><br>
<table align="center" border="0" cellpadding="0" cellspacing="0">
<tbody>
<tr><td valign="top" width="150">
<a href="CXO-90950.html">CXO 90950</a><br>
<a href="DTXO-090540.html">DTXO 090540</a><br>
<a href="DTXO-090541.html">DTXO 090541</a><br>
<a href="MXO-090860.html">MXO 090860</a><br>
<a href="MXO-090870.html">MXO 090870</a><br>
<a href="MXO1-090820.html">MXO1 090820</a><br>
<a href="OCXO-090460.html">OCXO 090460</a><br>
<a href="OCXO-090470.html">OCXO 090470</a><br>
<a href="OCXO-090530.html">OCXO 090530</a><br>
<a href="OCXO-090780.html">OCXO 090780</a><br>
<a href="OCXO-090800.html">OCXO 090800</a><br>
<a href="PKF-090695.html">PKF 090695</a><br>
<a href="PKF-090696.html">PKF 090696</a><br>
<a href="PKF-090700.html">PKF 090700</a><br>
<a href="PKJ-021191.html">PKJ 021191</a><br>
<a href="PKJ-021501.html">PKJ 021501</a><br>
<a href="PKJ-021581.html">PKJ 021581</a><br>
<a href="PKJ-021591.html">PKJ 021591</a><br>
<a href="PKJ-021601.html">PKJ 021601</a><br>
<a href="PKJ-021627.html">PKJ 021627</a><br>
<a href="PKJ-021710.html">PKJ 021710</a><br>
<a href="PKJ-031200.html">PKJ 031200</a><br>
<a href="PKJ-031201.html">PKJ 031201</a><br>
<a href="PKJ-031202.html">PKJ 031202</a><br>
<a href="PKJ-031220.html">PKJ 031220</a><br>
<a href="PKJ-031221.html">PKJ 031221</a><br>
<a href="PKJ-031222.html">PKJ 031222</a><br>
<a href="PKJ-031223.html">PKJ 031223</a><br>
<a href="PKJ-031224.html">PKJ 031224</a><br>
<a href="PKJ-031250.html">PKJ 031250</a><br>
<a href="PKJ-031251.html">PKJ 031251</a><br>
<a href="PKJ-031252.html">PKJ 031252</a><br>
<a href="PKJ-031253.html">PKJ 031253</a><br>
<a href="PKJ-031254.html">PKJ 031254</a><br>
<a href="PKJ-031255.html">PKJ 031255</a><br>
<a href="PKJ-031290.html">PKJ 031290</a><br>
<a href="PKJ-031291.html">PKJ 031291</a><br>
<a href="PKJ-031292.html">PKJ 031292</a><br>
<a href="PKJ-031293.html">PKJ 031293</a><br>
<a href="PKJ-031294.html">PKJ 031294</a><br>
<a href="PKJ-031295.html">PKJ 031295</a><br>
<a href="PKJ-031296.html">PKJ 031296</a><br>
<a href="PKJ-031297.html">PKJ 031297</a><br>
<a href="PKJ-031370.html">PKJ 031370</a><br>
<a href="PKJ-031371.html">PKJ 031371</a><br>
<a href="PKJ-031372.html">PKJ 031372</a><br>
<a href="PKJ-031373.html">PKJ 031373</a><br>
<a href="PKJ-031500.html">PKJ 031500</a><br>
<a href="PKJ-031501.html">PKJ 031501</a><br>
<a href="PKJ-031502.html">PKJ 031502</a><br>
<a href="PKJ-031520.html">PKJ 031520</a><br>
<a href="PKJ-031521.html">PKJ 031521</a><br>
<a href="PKJ-031522.html">PKJ 031522</a><br>
<a href="PKJ-031523.html">PKJ 031523</a><br>
<a href="PKJ-031524.html">PKJ 031524</a><br>
<a href="PKJ-031550.html">PKJ 031550</a><br>
<a href="PKJ-031551.html">PKJ 031551</a><br>
<a href="PKJ-031552.html">PKJ 031552</a><br>
<a href="PKJ-031553.html">PKJ 031553</a><br>
<a href="PKJ-031554.html">PKJ 031554</a><br>
<a href="PKJ-031555.html">PKJ 031555</a><br>
<a href="PKJ-031590.html">PKJ 031590</a><br>
<a href="PKJ-031591.html">PKJ 031591</a><br>
<a href="PKJ-031592.html">PKJ 031592</a><br>
<a href="PKJ-031593.html">PKJ 031593</a><br>
<a href="PKJ-031594.html">PKJ 031594</a><br>
<a href="PKJ-031595.html">PKJ 031595</a><br>
<a href="PKJ-031596.html">PKJ 031596</a><br>
<a href="PKJ-031597.html">PKJ 031597</a><br>
<a href="PKJ-031670.html">PKJ 031670</a><br>
<a href="PKJ-031671.html">PKJ 031671</a><br>
<a href="PKJ-031672.html">PKJ 031672</a><br>
<a href="PKJ-031673.html">PKJ 031673</a><br>
<a href="PKJ-031810.html">PKJ 031810</a><br>
<a href="PKJ-031811.html">PKJ 031811</a><br>
<a href="PKJ-031812.html">PKJ 031812</a><br>
<a href="PKJ-031813.html">PKJ 031813</a><br>
<a href="PKJ-031820.html">PKJ 031820</a><br>
<a href="PKJ-031821.html">PKJ 031821</a><br>
<a href="PKJ-031822.html">PKJ 031822</a><br>
<a href="PKJ-031823.html">PKJ 031823</a><br>
<a href="PKJ-031840.html">PKJ 031840</a><br>
<a href="PKJ-031841.html">PKJ 031841</a><br>

</td><td valign="top" width="150">
<a href="PKJ-031842.html">PKJ 031842</a><br>
<a href="PKJ-031850.html">PKJ 031850</a><br>
<a href="PKJ-031851.html">PKJ 031851</a><br>
<a href="PKJ-031852.html">PKJ 031852</a><br>
<a href="PKJ-031880.html">PKJ 031880</a><br>
<a href="PKJ-031881.html">PKJ 031881</a><br>
<a href="PKJ-031882.html">PKJ 031882</a><br>
<a href="PKJ-031883.html">PKJ 031883</a><br>
<a href="PKJ-031884.html">PKJ 031884</a><br>
<a href="PKJ-031885.html">PKJ 031885</a><br>
<a href="PKJ-031886.html">PKJ 031886</a><br>
<a href="PKJ-031887.html">PKJ 031887</a><br>
<a href="PKJ-031900.html">PKJ 031900</a><br>
<a href="PKJ-031901.html">PKJ 031901</a><br>
<a href="PKJ-031902.html">PKJ 031902</a><br>
<a href="PKJ-031903.html">PKJ 031903</a><br>
<a href="PKJ-031904.html">PKJ 031904</a><br>
<a href="PKJ-031905.html">PKJ 031905</a><br>
<a href="PKJ-031906.html">PKJ 031906</a><br>
<a href="PKJ-031907.html">PKJ 031907</a><br>
<a href="PKJ-041010.html">PKJ 041010</a><br>
<a href="PKJ-041020.html">PKJ 041020</a><br>
<a href="PKJ-041021.html">PKJ 041021</a><br>
<a href="PKJ-041022.html">PKJ 041022</a><br>
<a href="PKJ-041030.html">PKJ 041030</a><br>
<a href="PKJ-041031.html">PKJ 041031</a><br>
<a href="PKJ-041032.html">PKJ 041032</a><br>
<a href="PKJ-041105.html">PKJ 041105</a><br>
<a href="PKJ-041106.html">PKJ 041106</a><br>
<a href="PKJ-041115.html">PKJ 041115</a><br>
<a href="PKJ-041116.html">PKJ 041116</a><br>
<a href="PKJ-041120.html">PKJ 041120</a><br>
<a href="PKJ-041121.html">PKJ 041121</a><br>
<a href="PKJ-041130.html">PKJ 041130</a><br>
<a href="PKJ-041131.html">PKJ 041131</a><br>
<a href="PKJ-041140.html">PKJ 041140</a><br>
<a href="PKJ-041141.html">PKJ 041141</a><br>
<a href="PKJ-041150.html">PKJ 041150</a><br>
<a href="PKJ-041151.html">PKJ 041151</a><br>
<a href="PKJ-041310.html">PKJ 041310</a><br>
<a href="PKJ-041311.html">PKJ 041311</a><br>
<a href="PKJ-041320.html">PKJ 041320</a><br>
<a href="PKJ-041321.html">PKJ 041321</a><br>
<a href="PKJ-041322.html">PKJ 041322</a><br>
<a href="PKJ-041323.html">PKJ 041323</a><br>
<a href="PKJ-041330.html">PKJ 041330</a><br>
<a href="PKJ-041331.html">PKJ 041331</a><br>
<a href="PKJ-041332.html">PKJ 041332</a><br>
<a href="PKJ-041333.html">PKJ 041333</a><br>
<a href="PKJ-041360.html">PKJ 041360</a><br>
<a href="PKJ-041361.html">PKJ 041361</a><br>
<a href="PKJ-041370.html">PKJ 041370</a><br>
<a href="PKJ-041371.html">PKJ 041371</a><br>
<a href="PKJ-041380.html">PKJ 041380</a><br>
<a href="PKJ-041381.html">PKJ 041381</a><br>
<a href="PKJ-041382.html">PKJ 041382</a><br>
<a href="PKJ-041410.html">PKJ 041410</a><br>
<a href="PKJ-041411.html">PKJ 041411</a><br>
<a href="PKJ-041420.html">PKJ 041420</a><br>
<a href="PKJ-041421.html">PKJ 041421</a><br>
<a href="PKJ-041430.html">PKJ 041430</a><br>
<a href="PKJ-041431.html">PKJ 041431</a><br>
<a href="PKJ-041432.html">PKJ 041432</a><br>
<a href="PKJ-041433.html">PKJ 041433</a><br>
<a href="PKJ-041460.html">PKJ 041460</a><br>
<a href="PKJ-041461.html">PKJ 041461</a><br>
<a href="PKJ-041470.html">PKJ 041470</a><br>
<a href="PKJ-041480.html">PKJ 041480</a><br>
<a href="PKJ-051020.html">PKJ 051020</a><br>
<a href="PKJ-051021.html">PKJ 051021</a><br>
<a href="PKJ-051022.html">PKJ 051022</a><br>
<a href="PKJ-051030.html">PKJ 051030</a><br>
<a href="PKJ-051031.html">PKJ 051031</a><br>
<a href="PKJ-051040.html">PKJ 051040</a><br>
<a href="PKJ-051041.html">PKJ 051041</a><br>
<a href="PKJ-051042.html">PKJ 051042</a><br>
<a href="PKJ-051050.html">PKJ 051050</a><br>
<a href="PKJ-051051.html">PKJ 051051</a><br>
<a href="PKJ-051052.html">PKJ 051052</a><br>
<a href="PKJ-051053.html">PKJ 051053</a><br>
<a href="PKJ-051054.html">PKJ 051054</a><br>
<a href="PKJ-051110.html">PKJ 051110</a><br>
<a href="PKJ-051111.html">PKJ 051111</a><br>

</td><td valign="top" width="150">
<a href="PKJ-051130.html">PKJ 051130</a><br>
<a href="PKJ-051131.html">PKJ 051131</a><br>
<a href="PKJ-051132.html">PKJ 051132</a><br>
<a href="PKJ-051133.html">PKJ 051133</a><br>
<a href="PKJ-051134.html">PKJ 051134</a><br>
<a href="PKJ-051135.html">PKJ 051135</a><br>
<a href="PKJ-051136.html">PKJ 051136</a><br>
<a href="PKJ-051137.html">PKJ 051137</a><br>
<a href="PKJ-051138.html">PKJ 051138</a><br>
<a href="PKJ-051139.html">PKJ 051139</a><br>
<a href="PKJ-051140.html">PKJ 051140</a><br>
<a href="PKJ-051141.html">PKJ 051141</a><br>
<a href="PKJ-051142.html">PKJ 051142</a><br>
<a href="PKJ-051143.html">PKJ 051143</a><br>
<a href="PKJ-051144.html">PKJ 051144</a><br>
<a href="PKJ-051145.html">PKJ 051145</a><br>
<a href="PKJ-051146.html">PKJ 051146</a><br>
<a href="PKJ-051147.html">PKJ 051147</a><br>
<a href="PKJ-051148.html">PKJ 051148</a><br>
<a href="PKJ-051149.html">PKJ 051149</a><br>
<a href="PKJ-051150.html">PKJ 051150</a><br>
<a href="PKJ-051160.html">PKJ 051160</a><br>
<a href="PKJ-051161.html">PKJ 051161</a><br>
<a href="PKJ-051162.html">PKJ 051162</a><br>
<a href="PKJ-051163.html">PKJ 051163</a><br>
<a href="PKJ-051164.html">PKJ 051164</a><br>
<a href="PKJ-051165.html">PKJ 051165</a><br>
<a href="PKJ-051166.html">PKJ 051166</a><br>
<a href="PKJ-051167.html">PKJ 051167</a><br>
<a href="PKJ-051168.html">PKJ 051168</a><br>
<a href="PKJ-051169.html">PKJ 051169</a><br>
<a href="PKJ-051170.html">PKJ 051170</a><br>
<a href="PKJ-051171.html">PKJ 051171</a><br>
<a href="PKJ-051172.html">PKJ 051172</a><br>
<a href="PKJ-051190.html">PKJ 051190</a><br>
<a href="PKJ-051191.html">PKJ 051191</a><br>
<a href="PKJ-051200.html">PKJ 051200</a><br>
<a href="PKJ-051201.html">PKJ 051201</a><br>
<a href="PKJ-051202.html">PKJ 051202</a><br>
<a href="PKJ-051210.html">PKJ 051210</a><br>
<a href="PKJ-051211.html">PKJ 051211</a><br>
<a href="PKJ-051212.html">PKJ 051212</a><br>
<a href="PKJ-051213.html">PKJ 051213</a><br>
<a href="PKJ-051230.html">PKJ 051230</a><br>
<a href="PKJ-051231.html">PKJ 051231</a><br>
<a href="PKJ-051240.html">PKJ 051240</a><br>
<a href="PKJ-051241.html">PKJ 051241</a><br>
<a href="PKJ-051250.html">PKJ 051250</a><br>
<a href="PKJ-051251.html">PKJ 051251</a><br>
<a href="PKJ-051310.html">PKJ 051310</a><br>
<a href="PKJ-051311.html">PKJ 051311</a><br>
<a href="PKJ-051312.html">PKJ 051312</a><br>
<a href="PKJ-051320.html">PKJ 051320</a><br>
<a href="PKJ-051321.html">PKJ 051321</a><br>
<a href="PKJ-051322.html">PKJ 051322</a><br>
<a href="PKJ-051323.html">PKJ 051323</a><br>
<a href="PKJ-051340.html">PKJ 051340</a><br>
<a href="PKJ-051341.html">PKJ 051341</a><br>
<a href="PKJ-051342.html">PKJ 051342</a><br>
<a href="PKJ-051350.html">PKJ 051350</a><br>
<a href="PKJ-051351.html">PKJ 051351</a><br>
<a href="PKJ-051352.html">PKJ 051352</a><br>
<a href="PKJ-051370.html">PKJ 051370</a><br>
<a href="PKJ-051371.html">PKJ 051371</a><br>
<a href="PKJ-051380.html">PKJ 051380</a><br>
<a href="PKJ-051381.html">PKJ 051381</a><br>
<a href="PKJ-051382.html">PKJ 051382</a><br>
<a href="TCCXO1-090810.html">TCCXO1 090810</a><br>
<a href="TCCXO1-090840.html">TCCXO1 090840</a><br>
<a href="TCCXO1-090841.html">TCCXO1 090841</a><br>
<a href="TCCXO1-090842.html">TCCXO1 090842</a><br>
<a href="TCXO-090850.html">TCXO 090850</a><br>
<a href="TCXO-090880.html">TCXO 090880</a><br>
<a href="TCXO-090890.html">TCXO 090890</a><br>
<a href="VCXO1-090480.html">VCXO1 090480</a><br>
<a href="VCXO1-090481.html">VCXO1 090481</a><br>
<a href="VCXO1-090482.html">VCXO1 090482</a><br>
<a href="VCXO1-090483.html">VCXO1 090483</a><br>
<a href="VCXO1-090484.html">VCXO1 090484</a><br>
<a href="VCXO1-090485.html">VCXO1 090485</a><br>
<a href="VCXO1-090486.html">VCXO1 090486</a><br>

</td></tr>
</tbody></table>
<br><br>

</td>
      </tr>
    
    </tbody></table></td>
  </tr>
</tbody></table>
</center></body></html>
