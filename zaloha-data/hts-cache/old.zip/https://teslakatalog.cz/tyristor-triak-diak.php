<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>Tyristory, triaky, diaky</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<meta name="description" content="Katalog sou��stek - tyristory, triaky, diaky - n�hrada str�nek io.freehosting.cz a io1.freehosting.cz a jejich dopln�n�">
<meta name="keywords" content="katalog, list, Tesla, tyristor, triak, diak">
<link href="stylcss.css" type="text/css" rel="stylesheet"></head><body>
<center>
<table border="0" cellpadding="4" cellspacing="2" width="800">
  <tbody><tr valign="top">

      <td class="leftMain" align="left" width="180"><table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>
        <td align="left" height="200" valign="top"><table border="0" cellpadding="3" cellspacing="1" width="100%">
          
          <tbody><tr>
            <td class="forMenu2" align="center" height="71" valign="middle"><br><br><a href="http://teslakatalog.cz"><img src="ikony/tesla_logo.gif" alt=" " border="0" height="116" width="112"></a><br><br><br></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="http://teslakatalog.cz">O webu</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="io.php">Integrovan� obvody</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tranzistor.php">Tranzistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tyristor-triak-diak.php">Tyristory, triaky</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="dioda-varikap.php">Diody, varikapy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="led-dispej-fototranzistor.php">Displeje, LED</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="kondenzator.php">Kondenz�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="rezistor.php">Rezistory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="tlumivka.php">Tlumivky, filtry</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="xtal.php">Krystaly, oscil�tory</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="termistor.php">Termistory Pramet</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle">&nbsp;</td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="ke-stazeni.php">Ke sta�en�</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="https://vsevjednom.cz/guestbook.php?gb=30089&amp;lan=cs" target="_blank">Diskusn� kniha</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="left" height="25" valign="middle"><a href="linky.php">Odkazy</a></td>
          </tr>
          <tr>
            <td class="forMenu" align="center"><br><br>
          <!--Toplist-->
          <a href="http://www.toplist.cz/"><script language="JavaScript" type="text/javascript">
<!--
document.write ('<img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc&amp;http='+escape(document.referrer)+'&amp;wi='+escape(window.screen.width)+'&amp;he='+escape(window.screen.height)+'&amp;cd='+escape(window.screen.colorDepth)+'&amp;t='+escape(document.title)+'" width="88" height="120" border=0 alt="TOPlist" />');
//--></script></a><noscript><img src="http://toplist.cz/count.asp?id=696962&amp;logo=bc" border="0"
alt="TOPlist" width="88" height="120"></noscript>
            <br><br><br>
            </td>
          </tr>

        </tbody></table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </tbody></table></td>  

    <td class="rightMain" align="left"><table border="0" cellpadding="10" cellspacing="1" width="100%">
      
      <tbody><tr>
        <td class="forContent" align="center" valign="top"><!-- v�pis tyristor� -->
<br>
<h1>Tyristory, triaky, diaky</h1>
<hr><br>
<table align="center" border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="top" width="150">
<a href="KR100.html">KR100</a><br>
<a href="KR101-300.html">KR101/300</a><br>
<a href="KR101-400.html">KR101/400</a><br>
<a href="KR101-500.html">KR101/500</a><br>
<a href="KR105.html">KR105</a><br>
<a href="KR106.html">KR106</a><br>
<a href="KR107.html">KR107</a><br>
<a href="KR205.html">KR205</a><br>
<a href="KR206.html">KR206</a><br>
<a href="KR207.html">KR207</a><br>
<a href="KR9903.html">KR9903</a><br>
<a href="KT110.html">KT110</a><br>
<a href="KT110-200.html">KT110/200</a><br>
<a href="KT110-400.html">KT110/400</a><br>
<a href="KT110-600.html">KT110/600</a><br>
<a href="KT119A.html">KT119A</a><br>
<a href="KT120-500.html">KT120/500</a><br>
<a href="KT120A.html">KT120A</a><br>
<a href="KT128.html">KT128</a><br>
<a href="KT129.html">KT129</a><br>
<a href="KT201-100.html">KT201/100</a><br>
<a href="KT201-200.html">KT201/200</a><br>
<a href="KT201-300.html">KT201/300</a><br>
<a href="KT201-400.html">KT201/400</a><br>
<a href="KT201-500.html">KT201/500</a><br>
<a href="KT201-600.html">KT201/600</a><br>
<a href="KT205-200.html">KT205/200</a><br>
<a href="KT205-400.html">KT205/400</a><br>
<a href="KT205-600.html">KT205/600</a><br>
<a href="KT206-200.html">KT206/200</a><br>
<a href="KT206-400.html">KT206/400</a><br>
<a href="KT206-600.html">KT206/600</a><br>
<a href="KT207-200.html">KT207/200</a><br>
<a href="KT207-400.html">KT207/400</a><br>

</td><td valign="top" width="150">
<a href="KT207-600.html">KT207/600</a><br>
<a href="KT401-100.html">KT401/100</a><br>
<a href="KT401-200.html">KT401/200</a><br>
<a href="KT401-300.html">KT401/300</a><br>
<a href="KT401-400.html">KT401/400</a><br>
<a href="KT401-50.html">KT401/50</a><br>
<a href="KT401-500.html">KT401/500</a><br>
<a href="KT401-600.html">KT401/600</a><br>
<a href="KT401-700.html">KT401/700</a><br>
<a href="KT501.html">KT501</a><br>
<a href="KT502.html">KT502</a><br>
<a href="KT503.html">KT503</a><br>
<a href="KT504.html">KT504</a><br>
<a href="KT505.html">KT505</a><br>
<a href="KT506.html">KT506</a><br>
<a href="KT508-100.html">KT508/100</a><br>
<a href="KT508-200.html">KT508/200</a><br>
<a href="KT508-300.html">KT508/300</a><br>
<a href="KT508-400.html">KT508/400</a><br>
<a href="KT508-50.html">KT508/50</a><br>
<a href="KT511.html">KT511</a><br>
<a href="KT701.html">KT701</a><br>
<a href="KT702.html">KT702</a><br>
<a href="KT703.html">KT703</a><br>
<a href="KT704.html">KT704</a><br>
<a href="KT705.html">KT705</a><br>
<a href="KT706.html">KT706</a><br>
<a href="KT707.html">KT707</a><br>
<a href="KT708.html">KT708</a><br>
<a href="KT710.html">KT710</a><br>
<a href="KT711.html">KT711</a><br>
<a href="KT712.html">KT712</a><br>
<a href="KT713.html">KT713</a><br>
<a href="KT714.html">KT714</a><br>

</td><td valign="top" width="150">
<a href="KT725-100.html">KT725/100</a><br>
<a href="KT725-200.html">KT725/200</a><br>
<a href="KT725-300.html">KT725/300</a><br>
<a href="KT725-400.html">KT725/400</a><br>
<a href="KT725-50.html">KT725/50</a><br>
<a href="KT725-500.html">KT725/500</a><br>
<a href="KT725-600.html">KT725/600</a><br>
<a href="KT726-200.html">KT726/200</a><br>
<a href="KT726-400.html">KT726/400</a><br>
<a href="KT726-600.html">KT726/600</a><br>
<a href="KT726-800.html">KT726/800</a><br>
<a href="KT728-400.html">KT728/400</a><br>
<a href="KT728-600.html">KT728/600</a><br>
<a href="KT728-800.html">KT728/800</a><br>
<a href="KT729-700.html">KT729/700</a><br>
<a href="KT729-800.html">KT729/800</a><br>
<a href="KT729-900.html">KT729/900</a><br>
<a href="KT730-700.html">KT730/700</a><br>
<a href="KT730-800.html">KT730/800</a><br>
<a href="KT730-900.html">KT730/900</a><br>
<a href="KT772.html">KT772</a><br>
<a href="KT773.html">KT773</a><br>
<a href="KT774.html">KT774</a><br>
<a href="KT782.html">KT782</a><br>
<a href="KT783.html">KT783</a><br>
<a href="KT784.html">KT784</a><br>
<a href="KT803-400.html">KT803/400</a><br>
<a href="KT803-600.html">KT803/600</a><br>
<a href="KT803-800.html">KT803/800</a><br>
<a href="KT804-400.html">KT804/400</a><br>
<a href="KT804-600.html">KT804/600</a><br>
<a href="KT804-800.html">KT804/800</a><br>

</td></tr>
<tr><td colspan="3">
<br><br>
pouzdra tyristor�, triak�, diak�: <a href="io0/typ1.jpg">1</a>
</td></tr>
</tbody></table>
<br><br>

</td>
      </tr>
    
    </tbody></table></td>
  </tr>
</tbody></table>
</center></body></html>
